package com.websystique.springboot.service;


import java.awt.image.BufferedImage;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.websystique.springboot.model.User;

public interface UserService {
	
	BufferedImage findByName(HttpServletRequest request) throws InstantiationException, IllegalAccessException, ClassNotFoundException;
	
	
}
