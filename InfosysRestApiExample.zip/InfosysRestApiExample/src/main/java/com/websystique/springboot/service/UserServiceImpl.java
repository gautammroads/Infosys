package com.websystique.springboot.service;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.temesoft.security.image.PassImage;
import com.websystique.springboot.model.User;



@Service("userService")
public class UserServiceImpl implements UserService{
	
	
	
	
	
	public BufferedImage findByName(HttpServletRequest request) throws InstantiationException, IllegalAccessException, ClassNotFoundException  {
		
		return new PassImage().generateImg(request);
	}
	
	

}
