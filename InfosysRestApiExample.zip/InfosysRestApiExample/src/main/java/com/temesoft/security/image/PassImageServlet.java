package com.temesoft.security.image;

import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <a href="http://skewpassim.sourceforge.net/">http://skewpassim.sourceforge.net/</a>
 * <br>
 * <b>Servlet which generates a JPG image and sends it back
 * as content type: image/jpeg</b>
 */
public class PassImageServlet extends HttpServlet {
    /**
     * Redirects the request and response to doGet
     *
     * @param request
     * @param response
     * @throws ServletException
     */
    public void doPost(HttpServletRequest request,
                       HttpServletResponse response) throws ServletException {
        doGet(request, response);
    }

    /**
     * Calls the ISkewImage class to process and returns the image into response
     *
     * @param request
     * @param response
     * @throws ServletException
     */
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response) throws ServletException {
    	BufferedImage bufferedImage = null;
        try {
            response.setContentType("image/jpeg");
            PassImage pi = new PassImage();
            bufferedImage = pi.generateImg(request);
            ImageIO.write(bufferedImage, "jpeg", response.getOutputStream());
        } catch (ClassNotFoundException cnf) {
            cnf.printStackTrace();
            try {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception ex) {
            try {
                response.sendError(HttpServletResponse.SC_FORBIDDEN);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } finally {
        	if(bufferedImage != null) {
        		bufferedImage.flush();
        	}
        }
    }
}
