package com.temesoft.security.image;

import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.servlet.http.HttpServletRequest;

import com.temesoft.security.Base64Coder;
import com.temesoft.security.Config;
import com.temesoft.security.Encrypter;

public class PassImage {
	//Dont use BLACK
	//For SkewImageProba is using BLACK as default pen
    public static final Color [] RANDOM_BG_COLORS = {
    	new Color(0xbbc8ff), new Color(0xa5b0e3), new Color(0x93a6f8), new Color(0xb6c3fd)};
    //Dont use WHITE or COLOR used by RANDOM_BG_COLORS
    public static final Color [] RANDOM_FG_COLORS = {
        new Color(0x03411c), new Color(0x410315)};
	private static Encrypter _stringEncrypter = new Encrypter();
    private static final String SKEW_PROCESSOR_CLASS = Config.getProperty(Config.SKEW_PROCESSOR_CLASS);
	private static final String PASS_IMG_VER_KEY = "PASS_IMG_VER_KEY";
	
	public PassImage(){}
	
	public BufferedImage generateImg(HttpServletRequest request) throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		Encrypter stringEncrypter = new Encrypter();
    	String randomLetters = new String("");
        for (int i = 0; i < Config.getPropertyInt(Config.MAX_NUMBER); i++) {
            randomLetters += (char) (65 + (Math.random() * 24));

        }
        randomLetters = randomLetters.replaceAll("I","X");
        randomLetters = randomLetters.replaceAll("Q","Z");

        String passlineNormal = randomLetters + "." + request.getSession().getId();
        String passedKeyStr = stringEncrypter.encrypt(passlineNormal);
        passedKeyStr  = Base64Coder.encode(passedKeyStr);
        request.getSession().setAttribute(PASS_IMG_VER_KEY, passedKeyStr);
        
        String passstring = Base64Coder.decode(passedKeyStr);
        passedKeyStr = _stringEncrypter.decrypt(passstring);
        ClassLoader cl = Thread.currentThread().getContextClassLoader();
        String [] sprocessorClasses = SKEW_PROCESSOR_CLASS.split(":");
        ISkewImage skewImage = (ISkewImage) cl.loadClass(sprocessorClasses[(int) (Math.random() * sprocessorClasses.length)]).newInstance();
        BufferedImage bufferedImage = skewImage.skewImage(passedKeyStr.substring(0, passedKeyStr.indexOf(".")));
        return bufferedImage;
	}
	
	//If return result empty, means validate failed
	public String verifyImg(HttpServletRequest request, String passline){
		String passlineEncoded = (String) request.getSession().getAttribute(PASS_IMG_VER_KEY);
		if ((passline!=null) || (passlineEncoded !=null)) {

	        String passlineDecoded = Base64Coder.decode(passlineEncoded);
	        String passlineCheck = _stringEncrypter.decrypt(passlineDecoded);
	        String passlineString = passlineCheck;

	        passlineCheck = passlineCheck.substring(0, Config.getPropertyInt(Config.MAX_NUMBER));

	        String sessionId = passlineString.substring(
	                passlineString.indexOf(".")+1, passlineString.length());

	        if (!sessionId.equals(request.getSession().getId())) 
	            return "Encripted session is incorrect.";
	        
	        if (!passline.toUpperCase().equals(passlineCheck.toUpperCase())) 
	            return "Security code is incorrect.";
	        
	        return "";
	    }
		return "No Security code is found.";
	}
}
